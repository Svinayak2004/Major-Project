import React, { useState } from "react";
import "./DashboardHeader.css";

export function DashboardHeader({ notifications = 2, handleProfileAction }) {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <header className="header">
      {/* Left side: Logo + Title */}
      <div className="header-left">
        <div className="logo-box">
          <span className="logo-text">M</span>
        </div>
        <h1 className="dashboard-title">MedAI Dashboard</h1>
      </div>

      {/* Right side: Notifications + Profile */}
      <div className="header-right">
        {/* Notifications */}
        <button
          className="icon-btn"
          onClick={() => handleProfileAction?.("Notifications")}
        >
          🔔
          {notifications > 0 && (
            <span className="notification-badge">{notifications}</span>
          )}
        </button>

        {/* Profile Avatar */}
        <div className="profile-menu">
          <button
            className="avatar-btn"
            onClick={() => setDropdownOpen(!dropdownOpen)}
          >
            <div className="avatar">SJ</div>
          </button>

          {dropdownOpen && (
            <div className="dropdown">
              <div className="dropdown-header">
                <p className="name">Dr. Sarah Johnson</p>
                <p className="email">sarah.johnson@medai.com</p>
              </div>
              <hr />
              <button
                className="dropdown-item"
                onClick={() => handleProfileAction?.("Profile")}
              >
                👤 Profile
              </button>
              <button
                className="dropdown-item"
                onClick={() => handleProfileAction?.("Settings")}
              >
                ⚙️ Settings
              </button>
              <hr />
              <button
                className="dropdown-item logout"
                onClick={() => handleProfileAction?.("Logout")}
              >
                🚪 Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
